--Sample database manipulations for the project
--Group 97 John Cheng and John Hamrang

--Teams Page-----------------------------------------------------------------------
-- Reading in all Teams
SELECT * from Teams;

-- Adding a team to Teams
Insert into Teams (`team_name`, `year_established`, `league`, `division`, `owner`, `president`, `general_manager`, `manager`) 
Values (:team_name_input_add, :year_established_input_add, :league_input_add, :division_input_add, :owner_input_add, :president_input_add, :general_manager_input_add, :manager_input_add) ;

--Updating a Team
Update Teams SET `team_name` = :team_name_input_update, `year_established` = :year_established_input_update, `league` = :league_input_update, `division` = :division_input_update, `owner` = :owner_input_update, `president` = :president_input_update, `general_manager` = :general_manager_input_update, `manager` =:manager_input_update where team_id = :team_id_input_update ;


-- Deleting a team
DELETE from Teams where team_id =:team_id_delete_input;


--Locations Page-----------------------------------------------------------------------
--Reading in all Locations
SELECT * from Locations;

--Adding a location
Insert into Locations(`Teams_team_id`, `ballpark_name`, `date_opened`, `capacity`, `address`, `city`, `state`, `zip_code` )
Values((select Teams.team_id from Teams where team_name =: team_name_input_add), :ballpark_name_input_add, :date_opened_input_add, :capacity_input_add, :address_input_add, :city_input_add, state_input_add, :zip_code_input_add);

--Players Page-----------------------------------------------------------------------
--Reading in all players
SELECT * from Players;

--Finding players by team
Select * from Players where Players.team_id =: team_id_search;

--Adding a player
Insert into Players(`team_id`,	`name`,	`position`,	`salary`,	`start_date`,	`contract_end`,	`injury_status`,	`dominant_hand`,	`bat_type`)
Values ((select Teams.team_id from Teams where team_name =: team_name_input_add), :name_input_add, :position_input_add, :salary_input_add, :start_date_input_add, :contract_end_input_add, :injury_status_input_add, :dominant_hand_input_add, :bat_type_input_add)

--Updating a player
Update Players set `team_id` = (select Teams.team_id from Teams where team_name =: team_name_input_update), `name` =:name_input_update,	`position` =: position_input_update,	`salary` =: salary_input_update, `start_date` =: start_date_input_update, `contract_end` =:contract_end_input_update,	`injury_status`=:injury_status_input_update, `dominant_hand` =: dominant_hand_input_update,	`bat_type` =:bat_type_input_update where player_id =:player_id_input_update;

-- Deleting a player
DELETE from Players where player_id=: player_id_input_delete

--Games Page-----------------------------------------------------------------------
--Reading in all Games and adding other columns for user readability
Select Games.game_id, Games.home_team_score, Games.away_team_score, Games.date, Games.start_time, Games.innings, Games.num_ticket_sales, Games.num_concession_sales,Games.Locations_location_id,  Locations.ballpark_name from Games inner Join Locations  on  Games.Locations_location_id = Locations.location_id;


-- Finding the location_id
SELECT location_id FROM Locations WHERE ballpark_name = :ballpark_name_input_add;

-- finding all ballpark _name values so we can make a dropdown when trying to add a value
SELECT ballpark_name from Locations

--Add Game
Insert into Games (Locations_location_id, `home_team_score`, `away_team_score`,	`date`,	`start_time`,	`innings`, `num_ticket_sales`,	`num_concession_sales`)
Values((:location_game_add, :home_team_score_input_add, :away_team_score_input_add, :date_input_add, :start_time_input_add, :innings_input_add, :num_ticket_sales_input_add, :num_concession_sales_input_add);


--Delete a game
DELETE FROM Games WHERE game_id = :id;
--Updating Game (This is no longer being implemented)
--Update Games set Locations_location_id =(select Locations.location_id from Locations where ballpark_name =: ballpark_name_input_update), home_team_score =: home_team_score_input_update, away_team_score=:away_team_score_input_update, `date`=:date_input_update, start_time =: start_time_input_update, innings = innings_input_update, num_ticket_sales =: num_ticket_sales_input_update, num_concession_sales=: num_concession_sales_input_update where games_id =: games_id_input_update;

--Games_has_teams Page--------------------------------------------------------------
--Reading in all Games_has_Teams and adding in some values for user readability from other tables
select Games_has_Teams.games_has_teams_id, Games_has_Teams.game_id, Games.date, Games.start_time,Games.Locations_location_id,Locations.ballpark_name, Games_has_Teams.team_1_id, Teams.team_name from Games_has_Teams inner join Games on Games.game_id=Games_has_Teams.game_id inner join Teams on Teams.team_id = Games_has_Teams.team_1_id inner join Locations on Locations.location_id = Games.Locations_location_id;


-- Finding team_id
SELECT team_id FROM Teams WHERE team_name = :team_name_input_add;


--query to grab all team_names in Teams to display in dropdowns
SELECT team_name from Teams;

-- query to grab all games in Games so the user can add to Games_has_Teams and look at the id, and so game_id is in the dropdown
select Games.game_id, Games.date, Games.start_time, Games.Locations_location_id,  Locations.ballpark_name from Games inner Join Locations  on  Games.Locations_location_id = Locations.location_id;
      

--Adding a relation, where the id values were found using the above Finding statements
Insert into Games_has_Teams(`game_id`, `team_1_id`)
Values(:game_id_add, team_id_add);


--mySQL query to grab all team_names in Teams for dropdown purposes
SELECT team_name from Teams;

--Finding current row when updating
select Games_has_Teams.games_has_teams_id, Games_has_Teams.game_id, Games.date, Games.start_time,Games.Locations_location_id,Locations.ballpark_name, Games_has_Teams.team_1_id, Teams.team_name from Games_has_Teams inner join Games on Games.game_id=Games_has_Teams.game_id inner join Teams on Teams.team_id = Games_has_Teams.team_1_id inner join Locations on Locations.location_id = Games.Locations_location_id where games_has_teams_id =: id;


--Finding team_id when updating
SELECT team_id FROM Teams WHERE team_name = :team_name_input_update


--Updating Games_has_teams
UPDATE Games_has_Teams set game_id = :game_id_update,  team_1_id = :team_id_update Where games_has_teams_id = :id


--Deleting Games_has_Teams
DELETE from Games_has_Teams where games_has_teams_id =: games_has_teams_id_input_delete;
