# Code modified from the sample flask application given here: https://github.com/osu-cs340-ecampus/flask-starter-app
# as are the resulting .j2 files

from flask import Flask, render_template, json, redirect
from flask_mysqldb import MySQL
from flask import request
import os


app = Flask(__name__)

# database connection
# Template:
# app.config["MYSQL_HOST"] = "classmysql.engr.oregonstate.edu"
# app.config["MYSQL_USER"] = "cs340_OSUusername"
# app.config["MYSQL_PASSWORD"] = "XXXX" | last 4 digits of OSU id
# app.config["MYSQL_DB"] = "cs340_OSUusername"
# app.config["MYSQL_CURSORCLASS"] = "DictCursor"

# database connection info 
app.config["MYSQL_HOST"] = "classmysql.engr.oregonstate.edu"
app.config["MYSQL_USER"] = "cs340_OSUusername"
app.config["MYSQL_PASSWORD"] = "XXXX"
app.config["MYSQL_DB"] = "cs340_OSUusername"
app.config["MYSQL_CURSORCLASS"] = "DictCursor"

mysql = MySQL(app)

# Routes
# have homepage route to /index by default for convenience, generally this will be your home route with its own template
@app.route("/")
def home():
    return render_template("index.html")


# route for teams page
@app.route("/teams", methods=["POST", "GET"])
def teams():
    # Separate out the request methods, in this case this is for a POST
    # insert a team into the Teams entity
    if request.method == "POST":
        # fire off if user presses the Add Team button
        if request.form.get("Add_Team"):

            # grab user form inputs
            team_name_input_add = request.form["team_name_input_add"]
            year_established_input_add = request.form["year_established_input_add"]
            league_input_add = request.form["league_input_add"]
            division_input_add = request.form["division_input_add"]
            owner_input_add = request.form["owner_input_add"]
            president_input_add = request.form["president_input_add"]
            general_manager_input_add = request.form["general_manager_input_add"]
            manager_input_add = request.form["manager_input_add"]

            
            # Setting inputs that can be null to None if blank input was passed
            if owner_input_add=="":
                owner_input_add = None
            
            if president_input_add=="":
                president_input_add = None
            if general_manager_input_add =="": 
                general_manager_input_add = None
            if manager_input_add == "":    
                manager_input_add = None

            
            # mySQL query to insert a new team into Teams with our form inputs
            query = "Insert into Teams (team_name, year_established, league, division, owner, president, general_manager, manager) Values (%s, %s, %s, %s, %s, %s, %s, %s)"
            cur = mysql.connection.cursor()
            cur.execute(query, (team_name_input_add, year_established_input_add, league_input_add, division_input_add, owner_input_add, president_input_add, general_manager_input_add, manager_input_add))
            mysql.connection.commit()

            
            return redirect("/teams")

    # Grab teams data so we send it to our template to display
    if request.method == "GET":
        # mySQL query to grab all the teams in Teams
        query = "SELECT * from Teams"
        cur = mysql.connection.cursor()
        cur.execute(query)
        data = cur.fetchall()


        # render edit_teams page passing our query data 
        return render_template("teamsjj.j2", data=data)


# route for delete functionality, deleting a team from teams,
# we want to pass the 'id' value of that person on button click (see HTML) via the route
@app.route("/delete_teams/<int:id>")
def delete_teams(id):
    # mySQL query to delete the person with our passed id
    query = "DELETE FROM Teams WHERE team_id = %s" %(id)
    cur = mysql.connection.cursor()
    cur.execute(query)
    mysql.connection.commit()

    # redirect back to teams page
    return redirect("/teams")


@app.route("/edit_teams/<int:id>", methods=["POST", "GET"])
def edit_teams(id):
    if request.method == "GET":
        # mySQL query to grab the info of the person with our passed id
        query = "SELECT * FROM Teams WHERE team_id = %s" % (id)
        cur = mysql.connection.cursor()
        cur.execute(query)
        data = cur.fetchall()

        # render edit_teams page passing our query data and  data to the edit_teams template
        return render_template("edit_teams.j2", data=data)

    # meat and potatoes of our update functionality
    if request.method == "POST":
        # fire off if user clicks the 'Edit' button
        if request.form.get("Perform_Edits"):
            
            # grab user form inputs
            id = request.form["team_id_update"]
            team_name_input_update = request.form["team_name_input_update"]
            year_established_input_update = request.form["year_established_input_update"]
            league_input_update = request.form["league_input_update"]
            division_input_update = request.form["division_input_update"]
            owner_input_update = request.form["owner_input_update"]
            president_input_update = request.form["president_input_update"]
            general_manager_input_update = request.form["general_manager_input_update"]
            manager_input_update = request.form["manager_input_update"]

            
            # Setting inputs that can be null to None if blank input was passed
            if owner_input_update=="":
                owner_input_update = None
            
            if president_input_update=="":
                president_input_update = None
            if general_manager_input_update =="": 
                 general_manager_input_update = None
            if manager_input_update == "":    
                manager_input_update = None
                
        
            query = "UPDATE Teams set team_name = %s, year_established= %s, league= %s, division= %s, owner= %s, president= %s, general_manager= %s, manager= %s Where team_id = %s"
            cur = mysql.connection.cursor()
            cur.execute(query, (team_name_input_update, year_established_input_update, league_input_update, division_input_update, owner_input_update, president_input_update, general_manager_input_update, manager_input_update, id))
            mysql.connection.commit()



            # query = "UPDATE Teams set Teams.team_name = %s" % (team_name_input_update); ", Teams.year_established= %s " % (year_established_input_update); ", Teams.league= %s" % (league_input_update); ", Teams.division= %s" % (division_input_update); ", Teams.owner= %s" % (owner_input_update); ", Teams.president= %s" % (president_input_update); ", Teams.general_manager= %s" % (general_manager_input_update); ", Teams.manager= %s" % (manager_input_update); "Where Teams.team_id = %s" % (id)
            # cur = mysql.connection.cursor()
            # cur.execute(query)
            # mysql.connection.commit()




            # redirect back to teams page after we execute the update query
            return redirect("/teams")



@app.route("/games", methods=["POST", "GET"])
def games():
    # Separate out the request methods, in this case this is for a POST
    # insert a game into the Games entity
    if request.method == "POST":
        # fire off if user presses the Add Team button
        if request.form.get("Add_Game"):

            # grab user form inputs
            ballpark_name_input_add = request.form["ballpark_name_input_add"]
            home_team_score_input_add = request.form["home_team_score_input_add"]
            away_team_score_input_add = request.form["away_team_score_input_add"]
            date_input_add = request.form["date_input_add"]
            start_time_input_add = request.form["start_time_input_add"]
            innings_input_add = request.form["innings_input_add"]
            num_ticket_sales_input_add = request.form["num_ticket_sales_input_add"]
            num_concession_sales_input_add = request.form["num_concession_sales_input_add"]



            # ballpark_name_input_add = 3
            # home_team_score_input_add = 1
            # away_team_score_input_add = 1
            # date_input_add = '2022-01-10'
            # start_time_input_add = '10:00'
            # innings_input_add = 9
            # num_ticket_sales_input_add = 10000
            # num_concession_sales_input_add = 10001
            # location_game_add = 3
            
            # Finding location ID
            # query = "SELECT * from Locations WHERE ballpark_name = %s" %(ballpark_name_input_add) 
            query = "SELECT location_id FROM Locations WHERE ballpark_name = %s"
            cur = mysql.connection.cursor()
            cur.execute(query, (ballpark_name_input_add,))
            loc_data = cur.fetchone()
            location_game_add = loc_data["location_id"]
            
            
            # mySQL query to insert a new game into Games with our form inputs
            query = "Insert into Games (Locations_location_id, `home_team_score`, `away_team_score`, `date`, `start_time`, `innings`, `num_ticket_sales`, `num_concession_sales`) Values (%s, %s, %s, %s, %s, %s, %s, %s)"
            cur = mysql.connection.cursor()
            cur.execute(query, (location_game_add, home_team_score_input_add, away_team_score_input_add, date_input_add, start_time_input_add, innings_input_add, num_ticket_sales_input_add, num_concession_sales_input_add))
            mysql.connection.commit()

            
            return redirect("/games")

    # Grab game data so we send it to our template to display
    if request.method == "GET":
        # mySQL query to grab all the games in Games and ballpark_names for those games from Locations
        query = "select Games.game_id, Games.home_team_score, Games.away_team_score, Games.date, Games.start_time, Games.innings, Games.num_ticket_sales, Games.num_concession_sales,Games.Locations_location_id,  Locations.ballpark_name from Games inner Join Locations  on  Games.Locations_location_id = Locations.location_id"
        cur = mysql.connection.cursor()
        cur.execute(query)
        data = cur.fetchall()

        # mySQL query to grab all ballpark_names in Locations
        query = "SELECT ballpark_name from Locations"
        cur = mysql.connection.cursor()
        cur.execute(query)
        ballpark_name_data = cur.fetchall()



        # query = "SELECT location_id FROM Locations WHERE ballpark_name = 'Minute Maid Park'"
        # cur = mysql.connection.cursor()
        # cur.execute(query)
        # loc_data = cur.fetchone()
        # loc_data =loc_data["location_id"]

        # render games page passing our query data 
        return render_template("gamesjj2.j2", data=data, ballpark_name_data = ballpark_name_data)


# route for delete functionality, deleting a game from Games,
# we want to pass the 'id' value of that person on button click (see HTML) via the route
@app.route("/delete_games/<int:id>")
def delete_games(id):
    # mySQL query to delete the person with our passed id
    query = "DELETE FROM Games WHERE game_id = %s" %(id)
    cur = mysql.connection.cursor()
    cur.execute(query)
    mysql.connection.commit()

    # redirect back to games page
    return redirect("/games")


@app.route("/games_has_teams", methods=["POST", "GET"])
def games_has_teams():
    # Separate out the request methods, in this case this is for a POST
    # insert a game into the Games_has_Teams entity
    if request.method == "POST":
        # fire off if user presses the Add Games has Teams button
        if request.form.get("Add_Games_has_Teams"):

            # grab user form inputs
            game_id_input_add = request.form["game_id_input_add"]
            team_name_input_add = request.form["team_name_input_add"]

            
            # Finding game_ID
            game_id_add = game_id_input_add

            # Finding team_id
            query = "SELECT team_id FROM Teams WHERE team_name = %s"
            cur = mysql.connection.cursor()
            cur.execute(query, (team_name_input_add,))
            teams_data = cur.fetchone()
            team_id_add = teams_data["team_id"]             
            
            # mySQL query to insert a new Games_has_Teams entry  into Games_has_Teams with our form inputs
            query = "Insert into Games_has_Teams (`game_id`, `team_1_id`) Values (%s, %s)"
            cur = mysql.connection.cursor()
            cur.execute(query, (game_id_add, team_id_add))
            mysql.connection.commit()

            
            return redirect("/games_has_teams")

    # Grab game data so we send it to our template to display
    if request.method == "GET":
        # mySQL query to grab all the games in Games and ballpark_names for those games from Locations
        query = "select Games_has_Teams.games_has_teams_id, Games_has_Teams.game_id, Games.date, Games.start_time,Games.Locations_location_id,Locations.ballpark_name, Games_has_Teams.team_1_id, Teams.team_name from Games_has_Teams inner join Games on Games.game_id=Games_has_Teams.game_id inner join Teams on Teams.team_id = Games_has_Teams.team_1_id inner join Locations on Locations.location_id = Games.Locations_location_id"
        cur = mysql.connection.cursor()
        cur.execute(query)
        data = cur.fetchall()


        # mySQL query to grab all team_names in Teams
        query = "SELECT team_name from Teams"
        cur = mysql.connection.cursor()
        cur.execute(query)
        team_name_data = cur.fetchall()

        # mySQL query to grab all games in Games so the user can add to Games_has_Teams and look at the id, and so game_id is in the dropdown
        query = "select Games.game_id, Games.date, Games.start_time, Games.Locations_location_id,  Locations.ballpark_name from Games inner Join Locations  on  Games.Locations_location_id = Locations.location_id"
        cur = mysql.connection.cursor()
        cur.execute(query)
        game_data = cur.fetchall()
        
        


        # render games page passing our query data 
        return render_template("games_has_teamsjj.j2", data=data, team_name_data = team_name_data, game_data = game_data)


# route for delete functionality, deleting a game from Games,
# we want to pass the 'id' value of that person on button click (see HTML) via the route
@app.route("/delete_games_has_teams/<int:id>")
def delete_games_has_teams(id):
    # mySQL query to delete the games_has_teams with our passed id
    query = "DELETE FROM Games_has_Teams WHERE `games_has_teams_id` = %s" 
    cur = mysql.connection.cursor()
    cur.execute(query, (id,))
    mysql.connection.commit()

    # redirect back to games page
    return redirect("/games_has_teams")

@app.route("/edit_games_has_teams/<int:id>", methods=["POST", "GET"])
def edit_games_has_teams(id):
    if request.method == "GET":
        # mySQL query to grab the info of the person with our passed id
        query = "select Games_has_Teams.games_has_teams_id, Games_has_Teams.game_id, Games.date, Games.start_time,Games.Locations_location_id,Locations.ballpark_name, Games_has_Teams.team_1_id, Teams.team_name from Games_has_Teams inner join Games on Games.game_id=Games_has_Teams.game_id inner join Teams on Teams.team_id = Games_has_Teams.team_1_id inner join Locations on Locations.location_id = Games.Locations_location_id where games_has_teams_id =%s" % (id)
        cur = mysql.connection.cursor()
        cur.execute(query)
        data = cur.fetchall()

        # mySQL query to grab all games in Games so the user can add to Games_has_Teams and look at the id, and so game_id is in the dropdown
        query = "select Games.game_id, Games.date, Games.start_time, Games.Locations_location_id,  Locations.ballpark_name from Games inner Join Locations  on  Games.Locations_location_id = Locations.location_id"
        cur = mysql.connection.cursor()
        cur.execute(query)
        game_data = cur.fetchall()


        # mySQL query to grab all team_names in Teams so the user can add to Games_has_Teams and look at the id
        query = "select Teams.team_name from Teams"
        cur = mysql.connection.cursor()
        cur.execute(query)
        team_name_data = cur.fetchall()

        # render edit_teams page passing our query data and  data to the edit_teams template
        return render_template("edit_games_has_teamsjj.j2", data=data, game_data = game_data, team_name_data = team_name_data)

    # meat and potatoes of our update functionality
    if request.method == "POST":
        # fire off if user clicks the 'Edit' button
        if request.form.get("Perform_games_has_teams_Edits"):
            
            # grab user form inputs
            id = request.form["games_has_teams_id_update"]
            game_id_input_update = request.form["game_id_input_update"]
            team_name_input_update = request.form["team_name_input_update"]


            
            # Setting  game_id
            game_id_update = game_id_input_update

            # Finding team_id
            query = "SELECT team_id FROM Teams WHERE team_name = %s"
            cur = mysql.connection.cursor()
            cur.execute(query, (team_name_input_update,))
            teams_data = cur.fetchone()
            team_id_update = teams_data["team_id"]             
            
            
            # Updating
            query = "UPDATE Games_has_Teams set game_id = %s,  team_1_id = %s Where games_has_teams_id = %s"
            cur = mysql.connection.cursor()
            cur.execute(query, (game_id_update, team_id_update, id))
            mysql.connection.commit()



            # query = "UPDATE Teams set Teams.team_name = %s" % (team_name_input_update); ", Teams.year_established= %s " % (year_established_input_update); ", Teams.league= %s" % (league_input_update); ", Teams.division= %s" % (division_input_update); ", Teams.owner= %s" % (owner_input_update); ", Teams.president= %s" % (president_input_update); ", Teams.general_manager= %s" % (general_manager_input_update); ", Teams.manager= %s" % (manager_input_update); "Where Teams.team_id = %s" % (id)
            # cur = mysql.connection.cursor()
            # cur.execute(query)
            # mysql.connection.commit()




            # redirect back to teams page after we execute the update query
            return redirect("/games_has_teams")



# route for locations page
@app.route("/locations", methods=["POST", "GET"])
def locations():
    # Separate out the request methods, in this case this is for a POST
    # insert a location into the Locations entity
    if request.method == "POST":
        # fire off if user presses the Add Location button
        if request.form.get("Add_Location"):

            # grab user form inputs
            team_id_input_add = request.form["team_id_input_add"]
            ballpark_name_input_add = request.form["ballpark_name_input_add"]
            date_opened_input_add = request.form["date_opened_input_add"]
            capacity_input_add = request.form["capacity_input_add"]
            address_input_add = request.form["address_input_add"]
            city_input_add = request.form["city_input_add"]
            state_input_add = request.form["state_input_add"]
            zip_code_input_add = request.form["zip_code_input_add"]

            # mySQL query to insert a new location into Locations with our form inputs
            query = "Insert into Locations (ballpark_name, date_opened, capacity, address, city, state, zip_code, Teams_team_id) Values (%s, %s, %s, %s, %s, %s, %s, %s)"
            cur = mysql.connection.cursor()
            cur.execute(query, (ballpark_name_input_add, date_opened_input_add, capacity_input_add, address_input_add, city_input_add, state_input_add, zip_code_input_add, team_id_input_add))
            mysql.connection.commit()

            
            return redirect("/locations")

    # Grab locations data so we send it to our template to display
    if request.method == "GET":
        # mySQL query to grab all the locations in Locations
        query = "SELECT * from Locations"
        cur = mysql.connection.cursor()
        cur.execute(query)
        data = cur.fetchall()

        # mySQL query to grab all the team IDs and team names in Teams
        query2 = "SELECT team_id, team_name FROM Teams"
        cur = mysql.connection.cursor()
        cur.execute(query2)
        team_data = cur.fetchall()

        # render Locations page passing our query data 
        return render_template("locations.j2", data=data, team_data=team_data)

# route for players page
@app.route("/players", methods=["POST", "GET"])
def players():
    # Separate out the request methods, in this case this is for a POST
    # insert a player into the Players entity
    if request.method == "POST":
        # fire off if user presses the Add Player button
        if request.form.get("Add_Player"):

            # grab user form inputs
            team_id_input_add = request.form["team_id_input_add"]
            name_input_add = request.form["name_input_add"]
            position_input_add = request.form["position_input_add"]
            salary_input_add = request.form["salary_input_add"]
            start_date_input_add = request.form["start_date_input_add"]
            contract_end_input_add = request.form["contract_end_input_add"]
            injury_status_input_add = request.form["injury_status_input_add"]
            dominant_hand_input_add = request.form["dominant_hand_input_add"]
            bat_type_input_add = request.form["bat_type_input_add"]

            # mySQL query to insert a new player into Players with our form inputs
            query = "Insert into Players (name, position, salary, start_date, contract_end, injury_status, dominant_hand, bat_type, team_id) Values (%s, %s, %s, %s, %s, %s, %s, %s, %s)"
            cur = mysql.connection.cursor()
            cur.execute(query, (name_input_add, position_input_add, salary_input_add, start_date_input_add, contract_end_input_add, injury_status_input_add, dominant_hand_input_add, bat_type_input_add, team_id_input_add))
            mysql.connection.commit()
            
            return redirect("/players")

        if request.form.get("Find_Players"):

            #team_id_search = request.form["team_id_search"]
            team_id_search = request.form["team_id_search"]
            query = "SELECT * FROM Players WHERE Players.team_id = %s"
            cur = mysql.connection.cursor()
            cur.execute(query, (team_id_search))
            data = cur.fetchall()

            # mySQL query to grab all the team IDs and team names in Teams
            query2 = "SELECT team_id, team_name FROM Teams"
            cur = mysql.connection.cursor()
            cur.execute(query2)
            team_data = cur.fetchall()

            # render Locations page passing our query data 
            return render_template("players.j2", data=data, team_data = team_data)

    # Grab teams data so we send it to our template to display
    if request.method == "GET":

        # mySQL query to grab all the players in Players
        query = "SELECT * FROM Players"
        cur = mysql.connection.cursor()
        cur.execute(query)
        data = cur.fetchall()

        # mySQL query to grab all the team IDs and team names in Teams
        query2 = "SELECT team_id, team_name FROM Teams"
        cur = mysql.connection.cursor()
        cur.execute(query2)
        team_data = cur.fetchall()

        # render Locations page passing our query data 
        return render_template("players.j2", data=data, team_data = team_data)


# route for delete functionality, deleting a player from players,
# we want to pass the 'id' value of that person on button click (see HTML) via the route
@app.route("/delete_players/<int:id>")
def delete_players(id):
    # mySQL query to delete the person with our passed id
    query = "DELETE FROM Players WHERE player_id = %s" %(id)
    cur = mysql.connection.cursor()
    cur.execute(query)
    mysql.connection.commit()

    # redirect back to teams page
    return redirect("/players")

@app.route("/edit_players/<int:id>", methods=["POST", "GET"])
def edit_players(id):
    if request.method == "GET":
        # mySQL query to grab the info of the person with our passed id
        query = "SELECT * FROM Players WHERE player_id = %s" % (id)
        cur = mysql.connection.cursor()
        cur.execute(query)
        data = cur.fetchall()

        # mySQL query to grab all the team IDs and team names in Teams
        query2 = "SELECT team_id, team_name FROM Teams"
        cur = mysql.connection.cursor()
        cur.execute(query2)
        team_data = cur.fetchall()

        # render edit_teams page passing our query data and  data to the edit_teams template
        return render_template("edit_players.j2", data=data, team_data = team_data)

    # meat and potatoes of our update functionality
    if request.method == "POST":
        # fire off if user clicks the 'Edit' button
        if request.form.get("Edit_Player"):
            
            # grab user form inputs
            id = request.form["player_id_update"]

            team_id_input_update = request.form["team_id_input_update"]
            name_input_update = request.form["name_input_update"]
            position_input_update = request.form["position_input_update"]
            salary_input_update = request.form["salary_input_update"]
            start_date_input_update = request.form["start_date_input_update"]
            contract_end_input_update = request.form["contract_end_input_update"]
            injury_status_input_update = request.form["injury_status_input_update"]
            dominant_hand_input_update = request.form["dominant_hand_input_update"]
            bat_type_input_update = request.form["bat_type_input_update"]

            
            # Setting inputs that can be null to None if blank input was passed
            if start_date_input_update=="":
                start_date_input_update = None            
            if contract_end_input_update=="":
                contract_end_input_update = None
            if dominant_hand_input_update =="": 
                 dominant_hand_input_update = None
            if bat_type_input_update == "":    
                bat_type_input_update = None

            # account for null team_id
            if team_id_input_update == "None":
                query = "UPDATE Players set name= %s, position= %s, salary= %s, start_date= %s, contract_end= %s, injury_status= %s, dominant_hand= %s, bat_type= %s, team_id = NULL Where player_id = %s"
                cur = mysql.connection.cursor()
                cur.execute(query, (name_input_update, position_input_update, salary_input_update, start_date_input_update, contract_end_input_update, injury_status_input_update, dominant_hand_input_update, bat_type_input_update, id))
                mysql.connection.commit()

            else:
                query = "UPDATE Players set name= %s, position= %s, salary= %s, start_date= %s, contract_end= %s, injury_status= %s, dominant_hand= %s, bat_type= %s, team_id = %s Where player_id = %s"
                cur = mysql.connection.cursor()
                cur.execute(query, (name_input_update, position_input_update, salary_input_update, start_date_input_update, contract_end_input_update, injury_status_input_update, dominant_hand_input_update, bat_type_input_update, team_id_input_update, id))
                mysql.connection.commit()

            # redirect back to teams page after we execute the update query
            return redirect("/players")


# Listener
# change the port number if deploying on the flip servers
if __name__ == "__main__":
    app.run(port=XXXXX, debug=True)
