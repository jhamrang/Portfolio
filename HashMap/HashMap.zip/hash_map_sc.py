# Name: John Hamrang
# OSU Email: hamrangj@oregeonstate.edu
# Course: CS261 - Data Structures
# Assignment: 6 - Hash Maps
# Due Date: 3/11/2022
# Description: Hash Maps with chaining

from a6_include import *


def hash_function_1(key: str) -> int:
    """
    Sample Hash function #1 to be used with A5 HashMap implementation
    DO NOT CHANGE THIS FUNCTION IN ANY WAY
    """
    hash = 0
    for letter in key:
        hash += ord(letter)
    return hash


def hash_function_2(key: str) -> int:
    """
    Sample Hash function #2 to be used with A5 HashMap implementation
    DO NOT CHANGE THIS FUNCTION IN ANY WAY
    """
    hash, index = 0, 0
    index = 0
    for letter in key:
        hash += (index + 1) * ord(letter)
        index += 1
    return hash


class HashMap:
    def __init__(self, capacity: int, function) -> None:
        """
        Init new HashMap based on DA with SLL for collision resolution
        DO NOT CHANGE THIS METHOD IN ANY WAY
        """
        self.buckets = DynamicArray()
        for _ in range(capacity):
            self.buckets.append(LinkedList())
        self.capacity = capacity
        self.hash_function = function
        self.size = 0

    def __str__(self) -> str:
        """
        Overrides object's string method
        Return content of hash map t in human-readable form
        DO NOT CHANGE THIS METHOD IN ANY WAY
        """
        out = ''
        for i in range(self.buckets.length()):
            list = self.buckets.get_at_index(i)
            out += str(i) + ': ' + str(list) + '\n'
        return out

    def clear(self) -> None:
        """
        Clears the contents of the hash map, doesnt change the capacity
        """
        for index in range(0, self.capacity):
            self.buckets[index] = LinkedList()
        self.size = 0

    def get(self, key: str) -> object:
        """
        returns the value associated with a given key. if it does not, returns none
        """
        hashed = self.hash_function(key)
        hashed = hashed % self.capacity

        node = self.buckets[hashed].contains(key)
        if node is None:
            return None
        else:
            return node.value


        # if self.buckets[hashed] is None:
        #     return None
        # cur = self.buckets[test].head
        # while cur is not None or cur.key != key:
        #     cur = cur.next
        # if cur is None:
        #     return None
        # else:
        #     return cur.value



    def put(self, key: str, value: object) -> None:
        """
        Updates the key value pair in the hash map, if it doesnt extist it creates it, Also, I assumed its meant to update size
        """

        hashed = self.hash_function(key)
        hashed = hashed % self.capacity
        linked_list = self.buckets[hashed]
        if linked_list.length() != 0:
            cur = linked_list.head
            index = 0
            while cur is not None:
                if cur.key == key:
                    cur.value = value
                    return
                else:
                    cur = cur.next


        self.size += 1
        linked_list.insert(key, value)

        
        # if linked_list.head is None:
        #     linked_list.head = value
        # else:
        #     cur = linked_list.head
        #     while cur is not None or cur.key is not key:
        #         cur = cur.next
        #     temp = cur.next
        #     cur =SLNode(key, value)
        #     cur.next = temp


    def remove(self, key: str) -> None:
        """
        Removes the passed key from he map, if it is not there nothing is done
        """
        hashed = self.hash_function(key)
        hashed = hashed % self.capacity
        change_size = self.buckets[hashed].remove(key)
        if change_size is True:
            self.size -= 1



    def contains_key(self, key: str) -> bool:
        """
        Returns true or false if the hash map contains the passed key
        """
        hashed = self.hash_function(key)
        hashed = hashed % self.capacity
        bool = False
        if self.buckets[hashed].contains(key):
            bool = True
        return bool

    def empty_buckets(self) -> int:
        """
        Returns the number of empty buckets in the map
        """
        empty_bucket_ctr = 0
        for index in range(0, self.buckets.length()):
            if self.buckets[index].length() == 0:
                empty_bucket_ctr += 1

        return empty_bucket_ctr

    def table_load(self) -> float:
        """
        Calculates and returns the load factor of the hash map
        """
        num_elements = 0
        for index in range(0, self.capacity):
            linked_list = self.buckets[index]
            num_elements += linked_list.length()

        return num_elements/self.capacity


    def resize_table(self, new_capacity: int) -> None:
        """
        Resizes the table
        """
        if new_capacity < 1:
            return
        old_capacity = self.capacity
        self.capacity = new_capacity
        old_buckets = self.buckets
        self.buckets = DynamicArray()
        for _ in range(new_capacity):
            self.buckets.append(LinkedList())
        self.size = 0

        for index in range(0, old_capacity):
            if old_buckets[index].length() > 0:
                cur = old_buckets[index].head
                while cur is not None:
                    self.put(cur.key, cur.value)
                    cur = cur.next




    def get_keys(self) -> DynamicArray:
        """
        Creates/returns a dynamic array of all the keys in the map
        """
        key_array = DynamicArray()

        for index in range(0, self.capacity):
            if self.buckets[index].length() > 0:
                cur = self.buckets[index].head
                while cur is not None:
                    key_array.append(cur.key)
                    cur = cur.next

        return key_array


# BASIC TESTING
if __name__ == "__main__":

    print("\nPDF - empty_buckets example 1")
    print("-----------------------------")
    m = HashMap(100, hash_function_1)
    print(m.empty_buckets(), m.size, m.capacity)
    m.put('key1', 10)
    print(m.empty_buckets(), m.size, m.capacity)
    m.put('key2', 20)
    print(m.empty_buckets(), m.size, m.capacity)
    m.put('key1', 30)
    print(m.empty_buckets(), m.size, m.capacity)
    m.put('key4', 40)
    print(m.empty_buckets(), m.size, m.capacity)

    print("\nPDF - empty_buckets example 2")
    print("-----------------------------")
    m = HashMap(50, hash_function_1)
    for i in range(150):
        m.put('key' + str(i), i * 100)
        if i % 30 == 0:
            print(m.empty_buckets(), m.size, m.capacity)

    print("\nPDF - table_load example 1")
    print("--------------------------")
    m = HashMap(100, hash_function_1)
    print(m.table_load())
    m.put('key1', 10)
    print(m.table_load())
    m.put('key2', 20)
    print(m.table_load())
    m.put('key1', 30)
    print(m.table_load())

    print("\nPDF - table_load example 2")
    print("--------------------------")
    m = HashMap(50, hash_function_1)
    for i in range(50):
        m.put('key' + str(i), i * 100)
        if i % 10 == 0:
            print(m.table_load(), m.size, m.capacity)

    print("\nPDF - clear example 1")
    print("---------------------")
    m = HashMap(100, hash_function_1)
    print(m.size, m.capacity)
    m.put('key1', 10)
    m.put('key2', 20)
    m.put('key1', 30)
    print(m.size, m.capacity)
    m.clear()
    print(m.size, m.capacity)

    print("\nPDF - clear example 2")
    print("---------------------")
    m = HashMap(50, hash_function_1)
    print(m.size, m.capacity)
    m.put('key1', 10)
    print(m.size, m.capacity)
    m.put('key2', 20)
    print(m.size, m.capacity)
    m.resize_table(100)
    print(m.size, m.capacity)
    m.clear()
    print(m.size, m.capacity)
    
    print("\nPDF - put example 1")
    print("-------------------")
    m = HashMap(50, hash_function_1)
    for i in range(150):
        m.put('str' + str(i), i * 100)
        if i % 25 == 24:
            print(m.empty_buckets(), m.table_load(), m.size, m.capacity)

    print("\nPDF - put example 2")
    print("-------------------")
    m = HashMap(40, hash_function_2)
    for i in range(50):
        m.put('str' + str(i // 3), i * 100)
        if i % 10 == 9:
            print(m.empty_buckets(), m.table_load(), m.size, m.capacity)

    print("\nPDF - contains_key example 1")
    print("----------------------------")
    m = HashMap(10, hash_function_1)
    print(m.contains_key('key1'))
    m.put('key1', 10)
    m.put('key2', 20)
    m.put('key3', 30)
    print(m.contains_key('key1'))
    print(m.contains_key('key4'))
    print(m.contains_key('key2'))
    print(m.contains_key('key3'))
    m.remove('key3')
    print(m.contains_key('key3'))

    print("\nPDF - contains_key example 2")
    print("----------------------------")
    m = HashMap(75, hash_function_2)
    keys = [i for i in range(1, 1000, 20)]
    for key in keys:
        m.put(str(key), key * 42)
    print(m.size, m.capacity)
    result = True
    for key in keys:
        # all inserted keys must be present
        result &= m.contains_key(str(key))
        # NOT inserted keys must be absent
        result &= not m.contains_key(str(key + 1))
    print(result)

    print("\nPDF - get example 1")
    print("-------------------")
    m = HashMap(30, hash_function_1)
    print(m.get('key'))
    m.put('key1', 10)
    print(m.get('key1'))

    print("\nPDF - get example 2")
    print("-------------------")
    m = HashMap(150, hash_function_2)
    for i in range(200, 300, 7):
        m.put(str(i), i * 10)
    print(m.size, m.capacity)
    for i in range(200, 300, 21):
        print(i, m.get(str(i)), m.get(str(i)) == i * 10)
        print(i + 1, m.get(str(i + 1)), m.get(str(i + 1)) == (i + 1) * 10)

    print("\nPDF - remove example 1")
    print("----------------------")
    m = HashMap(50, hash_function_1)
    print(m.get('key1'))
    m.put('key1', 10)
    print(m.get('key1'))
    m.remove('key1')
    print(m.get('key1'))
    m.remove('key4')

    print("\nPDF - resize example 1")
    print("----------------------")
    m = HashMap(20, hash_function_1)
    m.put('key1', 10)
    print(m.size, m.capacity, m.get('key1'), m.contains_key('key1'))
    m.resize_table(30)
    print(m.size, m.capacity, m.get('key1'), m.contains_key('key1'))

    print("\nPDF - resize example 2")
    print("----------------------")
    m = HashMap(75, hash_function_2)
    keys = [i for i in range(1, 1000, 13)]
    for key in keys:
        m.put(str(key), key * 42)
    print(m.size, m.capacity)

    for capacity in range(111, 1000, 117):
        m.resize_table(capacity)

        m.put('some key', 'some value')
        result = m.contains_key('some key')
        m.remove('some key')

        for key in keys:
            result &= m.contains_key(str(key))
            result &= not m.contains_key(str(key + 1))
        print(capacity, result, m.size, m.capacity, round(m.table_load(), 2))

    print("\nPDF - get_keys example 1")
    print("------------------------")
    m = HashMap(10, hash_function_2)
    for i in range(100, 200, 10):
        m.put(str(i), str(i * 10))
    print(m.get_keys())
    
    m.resize_table(1)
    print(m.get_keys())

    m.put('200', '2000')
    m.remove('100')
    m.resize_table(2)
    print(m.get_keys())
