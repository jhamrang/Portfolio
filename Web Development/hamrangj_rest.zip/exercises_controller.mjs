import * as exercises from './exercises_model.mjs';
import express from 'express';

const PORT = 3000;

const app = express();

app.use(express.json());

/**
 * Create a new exercise with the name, reps, weight, unit, and date in the body
 */
//{ name: name, reps:reps, weight:weight, unit:unit, date: date}
 app.post('/exercises', (req, res) => {
    exercises.createExercise(req.body.name, req.body.reps, req.body.weight, req.body.unit, req.body.date)
        .then(exercise => {
            res.setHeader('Content-Type', 'application/json');
            res.status(201).json(exercise);
        })
        .catch(error => {
            console.error(error);
            // In case of an error, send back status code 400 in case of an error.
            // A better approach will be to examine the error and send an
            // error status code corresponding to the error.
            res.setHeader('Content-Type', 'application/json');
            res.status(400).json({ Error: 'Request failed' });
        });
});


/**
 * Retrive the exercise corresponding to the ID provided in the URL.
 */
 app.get('/exercises/:_id', (req, res) => {
    const exerciseId = req.params._id;
    exercises.findExercises(exerciseId)
        .then(exercise => { 
            res.setHeader('Content-Type', 'application/json');
            if (exercise !== null) {
                res.status(200).json(exercise);
            } else {
                res.status(404).json({ Error: 'Resource not found' });
            }         
         })
        .catch(error => {
            res.setHeader('Content-Type', 'application/json');
            res.status(400).json({ Error: 'Request failed' });
        });

});

/**
 * Retrieve exercises. 
 * If the query parameters include a date, then only the exercises for that date are returned. However this functionality is never used here, as all are returned every time in this assignment
 * Otherwise, all exercises are returned.
 */
 app.get('/exercises', (req, res) => {
    let filter = {};
    // Is there a query parameter named date? If so add a filter based on its value.
    if(req.query.date !== undefined){
        filter = { date: req.query.date };
    }
    exercises.findExercises(filter, '', 0)
        .then(exercises => {
            res.setHeader('Content-Type', 'application/json');
            res.status(200).json(exercises);
        })
        .catch(error => {
            res.setHeader('Content-Type', 'application/json');
            console.error(error);
            res.status(500).json({ error:error });
        });

});

/**
 * Update the exercise whose id is provided in the path parameter and set
 * its name, reps, weight, unit, and date to the values provided in the body.
 */
//{ name: name, reps:reps, weight:weight, unit:unit, date: date}

 app.put('/exercises/:_id', (req, res) => {
    exercises.replaceExercise(req.params._id, req.body.name, req.body.reps, req.body.weight, req.body.unit, req.body.date)
        .then(numUpdated => {
            res.setHeader('Content-Type', 'application/json');
            if (numUpdated === 1) {
                res.status(200).json({ _id: req.params._id, name: req.body.name, reps: req.body.reps, weight:req.body.weight , unit:req.body.unit , date:req.body.date})
            } else {
                res.status(404).json({ Error: 'Resource not found' });
            }
        })
        .catch(error => {
            res.setHeader('Content-Type', 'application/json');
            console.error(error);
            res.status(500).json({ error: error });
        });
});

/**
 * Delete the exercise whose id is provided in the query parameters
 */
 app.delete('/exercises/:_id', (req, res) => {
    exercises.deleteById(req.params._id)
        .then(deletedCount => {
            res.setHeader('Content-Type', 'application/json');
            if (deletedCount === 1) {
                res.status(204).send();
            } else {
                res.status(404).json({ Error: 'Resource not found' });
            }
        })
        .catch(error => {
            res.setHeader('Content-Type', 'application/json');
            console.error(error);
            res.status(500).json({ error: error });
        });
});
app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}...`);
});