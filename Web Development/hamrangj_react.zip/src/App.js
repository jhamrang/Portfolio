import './App.css';
import React from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import Navigation from './components/Navigation.js';
import HomePage from './pages/HomePage';
import CreateExercisePage from './pages/CreateExercisePage';
import EditExercisePage from './pages/EditExercisePage';
import {useState} from 'react'

function App() {
  const [exerciseToEdit, setExerciseToEdit] = useState();
  return (
    <div className="App">
      <header>
        <h1>Exercise Log</h1>
        <p>Please enter the name of the exercise, the number of reps, the weight, unit of weight, and date on the Add An Exercise prompt to log it. Edit and Delete functions are available by clicking the icons</p>
      </header>
      <main>
      <Router>
      <Navigation></Navigation>
        <div className="App-header">
          <Route path="/" exact>
            <HomePage setExerciseToEdit = {setExerciseToEdit}/>
          </Route>
          <Route path="/add-exercise">
            <CreateExercisePage />
          </Route>
          <Route path="/edit-exercise">
            <EditExercisePage exerciseToEdit = {exerciseToEdit}/>
          </Route>
          </div>
      </Router>
      </main>
      <footer> &copy; 2022 John Hamrang</footer>
    </div>
  );
}

export default App;