import React from 'react';
//import {MdDeleteForever} from 'react-icons/md';
import { RiDeleteBin7Fill, RiEdit2Fill } from "react-icons/ri";
//{ name: name, reps:reps, weight:weight, unit:unit, date: date}
function Exercise({ exercise, onDelete, onEdit }) {
    return (
        <tr>
            
            <td>{exercise.name}</td>
            <td>{exercise.reps}</td>
            <td>{exercise.weight}</td>
            <td>{exercise.unit}</td>
            <td>{exercise.date}</td>
            <td><RiEdit2Fill onClick={ () => onEdit(exercise)}/></td>
            <td><RiDeleteBin7Fill onClick={ () => onDelete(exercise._id)}/></td>
        </tr>
    );
}

export default Exercise;