import React from 'react';
import { Link } from 'react-router-dom';

function Navigation(){
    return(
        <article>
        <h2><nav className='Links'>
            <Link to="/"> Home </Link>          
            <Link to="/add-exercise"> Add An Exercise </Link>  
            </nav>
        </h2>

        
        </article>
    );
}
export default Navigation